from flask import Flask, render_template_string, Response, jsonify
import RPi.GPIO as GPIO
import cv2
import threading
import subprocess
import time
import sys
import base_motors

app = Flask(__name__)

# ================= MODE CONTROL =================
MODE = "MANUAL"
auto_process = None

# ================= CAMERA =================
camera = cv2.VideoCapture(0)

def generate_frames():
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# ================= HTML =================
@app.route('/')
def index():
    return render_template_string("""
    <html>
    <body style="text-align:center">
        <h2>WasteExpert Control</h2>

        <img src="/video_feed" width="480"><br><br>

        <button onclick="setMode('AUTO')">Automatic</button>
        <button onclick="setMode('MANUAL')">Manual</button>
        <br><br>

        <button onclick="send('forward')">Forward</button>
        <button onclick="send('backward')">Backward</button>
        <button onclick="send('left')">Left</button>
        <button onclick="send('right')">Right</button>
        <button onclick="send('stop')">Stop</button>

        <script>
        function send(cmd){
            fetch('/'+cmd);
        }
        function setMode(mode){
            fetch('/set_mode/'+mode)
            .then(res=>res.text())
            .then(data=>alert(data));
        }
        </script>
    </body>
    </html>
    """)

# ================= VIDEO ROUTE =================
@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

# ================= BIN STATUS (KEEP SAFE) =================
@app.route('/bin_levels')
def bin_levels():
    # Replace with your real bin logic if needed
    return jsonify({
        "dry_bin": "OK",
        "wet_bin": "OK"
    })

# ================= SENSOR STATUS =================
@app.route('/sensor_status')
def sensor_status():
    # Replace with your real sensor logic if needed
    return jsonify({
        "metal_sensor": "ACTIVE",
        "wet_sensor": "INACTIVE"
    })

# ================= MODE SWITCH =================
@app.route('/set_mode/<mode>')
def set_mode(mode):
    global MODE, auto_process

    if mode.upper() == "AUTO":

        if auto_process is None:
            auto_process = subprocess.Popen(
                ["sudo", "python3",
                 "/home/rpi/WasteExpert/Automatic/main_pi_ultra.py"]
            )

        MODE = "AUTO"
        return "Automatic Mode Activated"

    elif mode.upper() == "MANUAL":

        if auto_process is not None:
            auto_process.terminate()
            auto_process = None

        MODE = "MANUAL"
        return "Manual Mode Activated"

    return "Invalid Mode"

# ================= MANUAL CONTROLS =================
@app.route('/forward')
def forward():
    if MODE == "MANUAL":
        base_motors.forward()
    return "OK"

@app.route('/backward')
def backward():
    if MODE == "MANUAL":
        base_motors.backward()
    return "OK"

@app.route('/left')
def left():
    if MODE == "MANUAL":
        base_motors.left()
    return "OK"

@app.route('/right')
def right():
    if MODE == "MANUAL":
        base_motors.right()
    return "OK"

@app.route('/stop')
def stop():
    base_motors.stop()
    return "OK"

# ================= START SERVER =================
if __name__ == "__main__":
    print("🌐 WasteExpert Web Control + Mode Switching Started")
    app.run(host="0.0.0.0", port=5000)
