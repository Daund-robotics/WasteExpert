import subprocess
import sys
import os
import signal

AUTO_PATH = "/home/rpi/WasteExpert/Automatic/main_pi_ultra.py"
MANUAL_PATH = "/home/rpi/WasteExpert/Manual/main.py"

current_process = None

def stop_current():
    global current_process
    if current_process is not None:
        print("Stopping previous mode...")
        current_process.terminate()
        current_process.wait()
        current_process = None

def start_auto():
    global current_process
    stop_current()
    print("Starting Automatic Mode...")
    current_process = subprocess.Popen(["python3", AUTO_PATH])

def start_manual():
    global current_process
    stop_current()
    print("Starting Manual Mode...")
    current_process = subprocess.Popen(["python3", MANUAL_PATH])

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 mode_controller.py [auto/manual]")
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "auto":
        start_auto()
    elif mode == "manual":
        start_manual()
    else:
        print("Invalid mode. Use auto or manual.")
